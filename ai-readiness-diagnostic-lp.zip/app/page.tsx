import Image from "next/image";

const DIAGNOSIS_URL = "https://ai-qaw7.vercel.app/";

const concerns = [
  "ChatGPTを試したが、業務活用までは進んでいない",
  "AIを使う社員と使わない社員の差が大きい",
  "AIを何に使えばいいのか、現場が分かっていない",
  "人手不足なのに、同じ作業を人が繰り返している",
  "AI活用を進めたいが、社内ルールや教育体制がない",
  "情報漏洩やセキュリティ面が不安",
  "競合他社のAI活用に遅れを感じている"
];

const benefits = [
  "営業資料作成の時間削減",
  "議事録作成の自動化",
  "採用業務の効率化",
  "新人教育の標準化",
  "社内マニュアル作成",
  "問い合わせ対応の効率化",
  "社員の生産性向上",
  "属人化の解消"
];

const failureSteps = [
  "AIツールを導入する",
  "一部の社員だけが使う",
  "現場に定着しない",
  "成果が出ない",
  "結局使われなくなる"
];

const diagnosisItems = [
  "AI理解度",
  "現場での活用状況",
  "業務設計の状態",
  "社員教育と定着度",
  "応用活用の可能性",
  "セキュリティ管理",
  "リスク対策",
  "経営としての推進力"
];

function CtaButton({ label }: { label: string }) {
  return (
    <a className="cta-button" href={DIAGNOSIS_URL}>
      {label}
      <span aria-hidden="true">→</span>
    </a>
  );
}

function SectionHeader({
  eyebrow,
  title
}: {
  eyebrow?: string;
  title: string;
}) {
  return (
    <div className="section-header">
      {eyebrow ? <p className="eyebrow">{eyebrow}</p> : null}
      <h2>{title}</h2>
    </div>
  );
}

export default function Home() {
  return (
    <main>
      <section className="hero">
        <div className="hero__content">
          <p className="eyebrow">企業向けAI導入・定着度チェック</p>
          <h1>
            AIで伸びる会社と、
            <br />
            取り残される会社の違いとは？
          </h1>
          <div className="hero__copy">
            <p>
              人手不足、採用難、利益率の低下。その課題、本当に人を増やさなければ解決できないでしょうか。
            </p>
            <p>
              AIを導入するだけでは、会社は変わりません。重要なのは、社員がAIを使いこなし、売上・利益・生産性向上につなげられる組織になることです。
            </p>
            <p>まずは御社のAI活用レベルを確認してみてください。</p>
          </div>
          <CtaButton label="無料でAI活用レベルを診断する" />
          <p className="cta-note">約5分／無料診断／その場で結果表示</p>
        </div>
        <div className="hero__visual" aria-hidden="true">
          <Image
            src="/images/ai-executive-hero.png"
            alt=""
            fill
            priority
            sizes="(max-width: 900px) 100vw, 48vw"
          />
          <div className="hero__metric">
            <span>AI活用診断</span>
            <strong>8項目16問</strong>
          </div>
        </div>
      </section>

      <section className="section section--light">
        <div className="container">
          <SectionHeader title="AI活用、こんな状態で止まっていませんか？" />
          <ul className="check-list">
            {concerns.map((item) => (
              <li key={item}>{item}</li>
            ))}
          </ul>
          <p className="closing-copy">
            もし1つでも当てはまるなら、課題は「AIを導入していないこと」ではなく、
            <br />
            「AIを活用できる組織になっていないこと」かもしれません。
          </p>
        </div>
      </section>

      <section className="section">
        <div className="container narrow">
          <SectionHeader
            eyebrow="Market Shift"
            title="AIは、導入競争ではなく活用競争の時代へ"
          />
          <div className="story-copy">
            <p>
              かつて、パソコンを導入しただけの会社が勝ったわけではありません。パソコンを使いこなし、業務を変えた会社が成長しました。
            </p>
            <p>
              インターネットも同じです。ホームページを作っただけの会社ではなく、集客や営業に活用した会社が成果を出しました。
            </p>
            <p>
              AIも同じです。これから差が生まれるのは、AIを導入した会社ではなく、AIを使いこなせる会社です。
            </p>
          </div>
        </div>
      </section>

      <section className="section section--navy">
        <div className="container">
          <SectionHeader
            eyebrow="Management Theme"
            title="AI活用は、業務効率化ではなく利益改善のテーマです"
          />
          <div className="benefit-grid">
            {benefits.map((item) => (
              <article className="benefit-card" key={item}>
                {item}
              </article>
            ))}
          </div>
          <div className="impact-copy">
            <p>
              例えば、社員1人が1日30分の業務時間を削減できれば、月10時間、年間120時間の削減につながります。
            </p>
            <p>
              社員20名であれば、年間2,400時間。AI活用は、単なる便利ツールではなく、人手不足・利益改善・生産性向上に直結する経営テーマです。
            </p>
          </div>
        </div>
      </section>

      <section className="section section--light">
        <div className="container">
          <SectionHeader title="しかし、多くの企業が「導入しただけ」で止まっています" />
          <ol className="steps">
            {failureSteps.map((step, index) => (
              <li key={step}>
                <span>{String(index + 1).padStart(2, "0")}</span>
                {step}
              </li>
            ))}
          </ol>
          <p className="closing-copy">
            多くの企業で課題になるのは、AIツールの不足ではありません。
            <br />
            本当の課題は、社員のAI活用能力と、社内にAIを定着させる仕組みです。
          </p>
        </div>
      </section>

      <section className="section diagnosis">
        <div className="container diagnosis__inner">
          <div>
            <SectionHeader title="まずは、御社のAI活用レベルを見える化しませんか？" />
            <div className="story-copy">
              <p>
                AI活用を進める前に重要なのは、「今、自社がどのレベルにいるのか」を知ることです。
              </p>
              <p>
                この診断では、御社のAI活用状況を以下の観点から確認できます。
              </p>
            </div>
            <CtaButton label="無料でAI活用レベルを診断する" />
          </div>
          <div className="diagnosis-panel">
            <p>診断で分かること</p>
            <ul>
              {diagnosisItems.map((item) => (
                <li key={item}>{item}</li>
              ))}
            </ul>
          </div>
        </div>
      </section>

      <section className="final-cta">
        <div className="container narrow">
          <h2>
            AIを始めるかどうかではなく、
            <br />
            AIを使いこなせる組織になるかどうか
          </h2>
          <p>
            これからの差は、AIを知っている会社と、AIを使いこなしている会社で生まれます。
          </p>
          <p>
            まずは診断で、御社の現在地を確認してください。今取り組むべき課題と、次の一手が見えてきます。
          </p>
          <CtaButton label="今すぐ無料診断を開始する" />
        </div>
      </section>
    </main>
  );
}
