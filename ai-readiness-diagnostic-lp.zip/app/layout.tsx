import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title:
    "AIで伸びる会社と取り残される会社の違いとは？｜AI活用レベル無料診断",
  description:
    "人手不足、業務効率化、社員教育、利益改善に向けて、御社のAI活用レベルを無料診断。AIを導入するだけでなく、使いこなせる組織になるための現在地を見える化します。",
  openGraph: {
    title:
      "AIで伸びる会社と取り残される会社の違いとは？｜AI活用レベル無料診断",
    description:
      "御社のAI活用レベルを無料診断。使いこなせる組織になるための現在地を見える化します。",
    type: "website",
    images: ["/images/ai-executive-hero.png"]
  }
};

export default function RootLayout({
  children
}: Readonly<{
  children: ReactNode;
}>) {
  return (
    <html lang="ja">
      <body>{children}</body>
    </html>
  );
}
